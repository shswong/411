import java.io.*;
import java.util.*;
import java.util.regex.*;
/*
 * t_bool 		= 1000
 * t_break 		= 1001
 * t_class		= 1002
 * t_double		= 1003
 * t_else		= 1004
 * t_extends	= 1005
 * t_for			= 1006
 * t_if			= 1007
 * t_implements= 1008
 * t_int			= 1009
 * t_interface	= 1010
 * t_newarray	= 1011
 * t_println	= 1012
 * t_readln		= 1013
 * t_return		= 1014
 * t_string		= 1015
 * t_void		= 1016
 * t_while		= 1017
 * t_plus		= 1018
 * t_minus		= 1019
 * t_multiply	= 1020
 * t_division	= 1021
 * t_mod			= 1022
 * t_less		= 1023
 * t_lessequal	= 1024
 * t_greater	= 1025
 * t_greatrequal = 1026
 * t_equal		= 1027
 * t_notequal	= 1028
 * t_assignop	= 1029
 * t_semicolon	= 1030
 * t_comma		= 1031
 * t_period		= 1032
 * t_leftparen	= 1033
 * t_rightparen = 1034
 * t_leftbracket = 1035
 * t_rightbracket = 1036
 * t_leftbrace	= 1037
 * t_rightbrace = 1038
 * t_boolconstant	=	1039
 * t_intconstant	=	1040
 * t_doubleconstant = 1041
 * t_stringconstant = 1042
 * t_id			= 1043
 */

public class Lex
{
	private static File f;
	private static Scanner s;
	private static Matcher matcher;
	private static Queue<Integer> tokenizer;
	private static Trie t;
	
	public static void main(String[] args)
	{
		initialize(args[0]);
		while (s.hasNext())
		{
			String input = s.nextLine().trim();
			StringTokenizer tokens = new StringTokenizer(input, " [](){}><;=+-*/%!,.\"", true);
			Queue<String> q = new LinkedList<String>();
			while (tokens.hasMoreTokens())
			{
				q.add(tokens.nextToken());
			}
			System.out.println("REAL LINE: " + input);
			while (!q.isEmpty())
			{
				String next = q.poll();
				//System.out.println(next);
				if (q.peek() != null && isComment(next, q.peek()) == 1) { q.clear();	}	// comments
				else if (q.peek() != null && isComment(next, q.peek()) == 2)				// comments
				{
					q.clear();
					while (!input.contains("*/"))
					{
						input = s.nextLine();
					}
				} 
				else if (isKeyword(next)) { t.add(next); }				
				else if (isBoolean(next)) { tokenizer.add(1039); }
				else if (isIdentifier(next)) { tokenizer.add(1043); t.add(next); }
				else if (isDouble(next) == 1) { tokenizer.add(1041); q.poll(); q.poll(); }
				else if (isInteger(next)) { tokenizer.add(1040); }
				else if (isDouble(next) == 2) { tokenizer.add(1041); }
				else if (next.equals("\""))															// string constant
				{
					do
					{
						next = q.poll();
					} while (!next.equals("\""));
					tokenizer.add(1042);
				}
				else if (isMultiword(next)) { }
				else if (next.equals("(")) { tokenizer.add(1033); }				// everything below are operators and punctuation
				else if (next.equals(")")) { tokenizer.add(1034); }
				else if (next.equals("[")) { tokenizer.add(1035); }
				else if (next.equals("]")) { tokenizer.add(1036); }
				else if (next.equals("{")) { tokenizer.add(1037); }
				else if (next.equals("}")) { tokenizer.add(1038); }
				else if (next.equals(">") && q.peek().equals("=")) { tokenizer.add(1026); q.poll(); }
				else if (next.equals(">")) { tokenizer.add(1025); }
				else if (next.equals("<") && q.peek().equals("=")) { tokenizer.add(1024); q.poll(); }
				else if (next.equals("<")) { tokenizer.add(1023); }
				else if (next.equals("+")) { tokenizer.add(1018); }
				else if (next.equals("-")) { tokenizer.add(1019); }
				else if (next.equals("*")) { tokenizer.add(1020); }
				else if (next.equals("/")) { tokenizer.add(1021); }
				else if (next.equals("%")) { tokenizer.add(1022); }
				else if (next.equals(";")) { tokenizer.add(1030); }
				else if (next.equals("=") && q.peek().equals("=")) { tokenizer.add(1027); q.poll(); }
				else if (next.equals("!") && q.peek().equals("=")) { tokenizer.add(1028); q.poll(); }
				else if (next.equals("=")) { tokenizer.add(1029); }
				else if (next.equals(",")) { tokenizer.add(1031); }
				else if (next.equals(".")) { tokenizer.add(1032); }
			}
			printTokens();
			System.out.println();
			System.out.println();
		}
		t.print();
	}
	
	private static void initialize(String file)
	{
		try
		{
			f = new File(file);
			s = new Scanner(f);
		}
		catch (FileNotFoundException e)
		{
			System.out.println(e.toString());
		}
		tokenizer = new LinkedList<Integer>();
		t = new Trie();
	}
	
	private static void printTokens()
	{
		while (!tokenizer.isEmpty())
		{
			int i = tokenizer.poll();
			if (i == 1000) { System.out.print("bool "); }
			else if (i == 1001) { System.out.print("break "); }
			else if (i == 1002) { System.out.print("class "); }
			else if (i == 1003) { System.out.print("double "); }
			else if (i == 1004) { System.out.print("else "); }
			else if (i == 1005) { System.out.print("extends "); }
			else if (i == 1006) { System.out.print("for "); }
			else if (i == 1007) { System.out.print("if "); }
			else if (i == 1008) { System.out.print("implements "); }
			else if (i == 1009) { System.out.print("int "); }
			else if (i == 1010) { System.out.print("interface "); }
			else if (i == 1011) { System.out.print("newarray "); }
			else if (i == 1012) { System.out.print("println "); }
			else if (i == 1013) { System.out.print("readln "); }
			else if (i == 1014) { System.out.print("return "); }
			else if (i == 1015) { System.out.print("string "); }
			else if (i == 1016) { System.out.print("void "); }
			else if (i == 1017) { System.out.print("while "); }
			else if (i == 1018) { System.out.print("add "); }
			else if (i == 1019) { System.out.print("minus "); }
			else if (i == 1020) { System.out.print("multiply "); }
			else if (i == 1021) { System.out.print("divide "); }
			else if (i == 1022) { System.out.print("mod "); }
			else if (i == 1023) { System.out.print("less "); }
			else if (i == 1024) { System.out.print("lessequal "); }
			else if (i == 1025) { System.out.print("greater "); }
			else if (i == 1026) { System.out.print("greaterequal "); }
			else if (i == 1027) { System.out.print("equal "); }
			else if (i == 1028) { System.out.print("notequal "); }
			else if (i == 1029) { System.out.print("assign "); }
			else if (i == 1030) { System.out.print("semicolon "); }
			else if (i == 1031) { System.out.print("comma "); }
			else if (i == 1032) { System.out.print("period "); }
			else if (i == 1033) { System.out.print("leftparen "); }
			else if (i == 1034) { System.out.print("rightparen "); }
			else if (i == 1035) { System.out.print("leftbracket "); }
			else if (i == 1036) { System.out.print("rightbracket "); }
			else if (i == 1037) { System.out.print("leftbrace "); }
			else if (i == 1038) { System.out.print("rightbrace "); }
			else if (i == 1039) { System.out.print("boolconstant "); }
			else if (i == 1040) { System.out.print("intconstant "); }
			else if (i == 1041) { System.out.print("doubleconstant "); }
			else if (i == 1042) { System.out.print("stringconstant "); }
			else if (i == 1043) { System.out.print("id "); }
		}
	}
	
	private static boolean isKeyword(String input)
	{
		if (input.equals("bool")) { tokenizer.add(1000); return true; }
		else if (input.equals("break")) { tokenizer.add(1001); return true; }
		else if (input.equals("class")) { tokenizer.add(1002); return true; }
		else if (input.equals("double")) { tokenizer.add(1003); return true; }
		else if (input.equals("else")) { tokenizer.add(1004); return true; }
		else if (input.equals("extends")) { tokenizer.add(1005); return true; }
		else if (input.equals("for")) { tokenizer.add(1006); return true; }
		else if (input.equals("if")) { tokenizer.add(1007); return true; }
		else if (input.equals("implements")) { tokenizer.add(1008); return true; }
		else if (input.equals("int")) { tokenizer.add(1009); return true; }
		else if (input.equals("interface")) { tokenizer.add(1010); return true; }
		else if (input.equals("newarray")) { tokenizer.add(1011); return true; }
		else if (input.equals("println")) { tokenizer.add(1012); return true; }
		else if (input.equals("readln")) { tokenizer.add(1013); return true; }
		else if (input.equals("return")) { tokenizer.add(1014); return true; }
		else if (input.equals("string")) { tokenizer.add(1015); return true; }
		else if (input.equals("void")) { tokenizer.add(1016); return true; }
		else if (input.equals("while")) { tokenizer.add(1017); return true; }
		return false;
	}
	
	private static boolean isIdentifier(String input)
	{
		Pattern identifier = Pattern.compile("[A-Za-z][A-Za-z0-9_]*+");
		matcher = identifier.matcher(input);
		if (matcher.matches()) { return true; }
		return false;
	}
	
	private static boolean isInteger(String input)
	{
		Pattern hexadecimal = Pattern.compile("(0x|0X)[0-9A-Fa-f]*+");
		Pattern decimal = Pattern.compile("[0-9]*");
		matcher = hexadecimal.matcher(input);
		if (matcher.matches()) { return true; }
		matcher = decimal.matcher(input);
		if (matcher.matches()) { return true; }
		return false;
	}
	
	private static int isDouble(String input)
	{
		Pattern decimaldouble = Pattern.compile("[0-9]+(.)[0-9]*");
		Pattern scientificdouble = Pattern.compile("[0-9]+[0-9]*E+[0-9]*");
		matcher = scientificdouble.matcher(input);
		if (matcher.matches()) { return 1; } // returns scientificdouble match
		matcher = decimaldouble.matcher(input);
		if (matcher.matches()) { return 2; } // returns decimaldouble match
		return 0;
	}
	
	private static boolean isBoolean(String input)
	{
		if (input.equals("true") || input.equals("false")) { return true; }
		return false;
	}
	
	private static int isComment(String t1, String t2)
	{
		if (t1.equals("/") && t2.equals("/")) { return 1; }		// returns single line comment match
		else if (t1.equals("/") && t2.equals("*")) { return 2; } // returns block comment match
		return 0;
	}
	
	private static boolean isMultiword(String input)	// breaks ids certain special ids, such as 23void
	{
		Pattern ints = Pattern.compile("\\d+");
		matcher = ints.matcher(input);
		matcher.find();
		try
		{
			String inputInt = matcher.group();			// will hold the integer
		}
		catch (IllegalStateException e) { return false; }
		
		String[] splitter = input.split("\\d+");
		
		for (String s : splitter)
		{
			if (isKeyword(s)) { }
			else if (isBoolean(s)) { tokenizer.add(1039); }
			else if (isIdentifier(s)) { tokenizer.add(1043); t.add(s); }
			else if (isInteger(s)) { tokenizer.add(1040); }
			else if (isDouble(s) == 2) { tokenizer.add(1041); }
		}
		
		return true;
	}
}
