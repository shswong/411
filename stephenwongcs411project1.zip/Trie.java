//a	0	26
//b	1	27
//c	2	28
//d	3	29
//e	4	30
//f	5	31
//g	6	32
//h	7	33
//i	8	34
//j	9	35
//k	10	36
//l	11	37
//m	12	38
//n	13	39
//o	14	40
//o	15	41
//q	16	42
//r	17	43
//s	18	44
//t	19	45
//u	20	46
//v	21	47
//w	22	48
//x	23	49
//y	24	50
//z	25	51
import java.util.*;

public class Trie
{
	private int[] switch_array;
	private char[] switch_alpha = {'a','b','c','d','e','f','g','h'
											,'i','j','k','l','m','n','o','p','q'
											,'r','s','t','u','v','w','x','y','z'
											,'A','B','C','D','E','F','G','H'
											,'I','J','K','L','M','N','O','P','Q'
											,'R','S','T','U','V','W','X','Y','Z'};
	private char[] symbol;
	private int[] next;
	private final int max = 150;
	
	public Trie()
	{
		switch_array = new int[52];
		symbol = new char[max];
		next = new int[max];
		
		/*
		 * -1 corresponds to blank values for switch_array and next
		 * ' ' corresponds to blank values for symbol
		 */
		
		for (int i = 0; i < max; i++)
		{
			if (i < 52) { switch_array[i] = -1; }
			symbol[i] = ' ';
			next[i] = -1;
		}
	}
	
	public void add(String input)
	{
		if (input.length() == 0) { return; }					// case of input.length() == 0
		Queue<Character> q = initialize(input);
		char first_char = q.poll();								// value_of_symbol <- NextSymbol (data);
		
		int pointer = search_switchalpha(first_char);		// act as the pointer for filling in symbol table
																			// ptr <- switch [value_of_symbol];
		
		if (pointer == -1)											//if ptr is undefined then Create
		{
			pointer = search_available();
			fill_switcharray(pointer, first_char);
			
			if (q.isEmpty()) { symbol[pointer] = '@'; }		// case of input.length() == 1
			
			while (!q.isEmpty())										// create
			{
				char next_char = q.poll();
				symbol[pointer++] = next_char;
				if (q.isEmpty()) { symbol[pointer] = '@'; }
			}
		}
		else 
		{
			if (q.isEmpty()) { symbol[pointer] = '@'; return; }		// case of input.length() == 1
			char next_char = q.poll();											// value_of_symbol <- NextSymbol (data);
			
			while (!q.isEmpty())													// accept and remove equivalent chars
			{
				if (next_char == symbol[pointer++])	{ next_char = q.poll(); }
				else { break; }
			}
			
			int next_pointer = 0;												// if next [ptr] is defined then ptr <- next [ptr]
			if (next[pointer] == -1) { next_pointer = search_available(); }
			else { next_pointer = next[pointer]; }
			next[pointer] = next_pointer;
			
			while (!q.isEmpty())													// create
			{
				symbol[next_pointer] = next_char;
				next_char = q.poll();
				next_pointer++;
				if (q.isEmpty())
				{
					symbol[next_pointer++] = next_char;
					symbol[next_pointer] = '@';
				}
			}
		}
	}
	
	public void print()
	{
		System.out.println("First row are the positions in each corresponding array");
		System.out.println("Second row is the entire alphabet");
		System.out.println("Third row is the switch array values for the corresponding alphabet");
		System.out.println("Fourth row is the symbol array");
		System.out.println("Fifth row is the next array for the corresponding symbol values");
		
		for (int i = 0; i < max; i++)
		{
			System.out.print(i+"\t"); 
		}
		System.out.println();
		
		for (int i = 0; i < 52; i++)
		{
			System.out.print(switch_alpha[i]+"\t");
		}
		System.out.println();
		
		for (int i = 0; i < 52; i++)
		{
			if (switch_array[i] == -1) { System.out.print("-\t"); }
			else { System.out.print(switch_array[i]+"\t"); }
		}
		System.out.println();
		
		for (int i = 0; i < max; i++)
		{
			if (symbol[i] == ' ') { System.out.print("-\t"); }
			else { System.out.print(symbol[i]+"\t"); }
		}
		System.out.println();
		
		for (int i = 0; i < max; i++)
		{
			if (next[i] == -1) { System.out.print("-\t"); }
			else { System.out.print(next[i]+"\t"); }
		}
		System.out.println();
		System.out.println();
	}
	
	private Queue<Character> initialize(String input)					// change the string to a queue structure
	{
		Queue<Character> q = new LinkedList<Character>();
		char[] chars = input.toCharArray();
		for (char c : chars)
		{
			q.add(c);
		}
		return q;
	}
	
	private int search_switchalpha(char c)
	{
		for (int i = 0; i < 52; i++)
		{
			if (switch_alpha[i] == c) { return switch_array[i]; }		// find the value from the switch array for a given char c
		}
		return -1;	// return empty
	}
	
	private void fill_switcharray(int s, char c)
	{
		for (int i = 0; i < 52; i++)
		{
			if (switch_alpha[i] == c) { switch_array[i] = s; }			// search given char c from switch_alpha and fill in switch_array 
																						// at same position with newly available s
		}
	}
	
	private int search_available()
	{
		for (int i = 0; i < max; i++)
		{
			if (symbol[i] == ' ') { return i; }								// find first empty position in symbol
		}
		return 0;
	}
}
